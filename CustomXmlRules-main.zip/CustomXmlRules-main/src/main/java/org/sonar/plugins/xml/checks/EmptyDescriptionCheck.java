package org.sonar.plugins.xml.checks;

import javax.xml.xpath.XPathExpression;

import org.sonar.check.Rule;
import org.sonarsource.analyzer.commons.xml.XmlFile;
import org.sonarsource.analyzer.commons.xml.checks.SimpleXPathBasedCheck;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.util.List;

@Rule(key = "EmptyDescriptionCheck")
public class EmptyDescriptionCheck extends SimpleXPathBasedCheck {

    public static final String FIELDS = "fields";
    public static final String DESCRIPTION = "Description";
    public static final String NAME = "Name";
    public static final String CUSTOM = "__c";
    private final String MESSAGE = ChecksBundle.getStringFromBundle("EmptyDescriptionCheck");
    private XPathExpression descriptionTag = getXPathExpression(
            "//CustomObject");

    private static boolean hasDescription = false;
    private static boolean isCustomObject = false;

    @Override
    public void scanFile(XmlFile file) {
        evaluateAsList(descriptionTag, file.getNamespaceUnawareDocument()).forEach(this::checkProperty);

    }

    private void checkProperty(Node description) {
        NodeList children = description.getChildNodes();
        for (int i = 0; i < children.getLength(); i++) {
            if (children.item(i).getNodeType() == Node.ELEMENT_NODE) {
                if (FIELDS.equals(children.item(i).getNodeName())) {
                    NodeList fieldChild = children.item(i).getChildNodes();
                    for (int j = 0; j < fieldChild.getLength(); j++) {

                        if (fieldChild.item(j).getNodeName().contains(NAME)) {
                            if (fieldChild.item(j).getTextContent().contains(CUSTOM)) {
                                isCustomObject = true;
                            }
                        }
                        if (fieldChild.item(j).getNodeName().equalsIgnoreCase(DESCRIPTION)) {
                            hasDescription = true;

                            String desc = fieldChild.item(j).getTextContent().trim();
                            if (desc.length() < 1) {
                                hasDescription = false;
                            }
                        }
                    }
                    if (!hasDescription && isCustomObject) {
                        reportIssue(children.item(i), MESSAGE);
                    }
			isCustomObject = false;
			hasDescription = false;
                }
            }


        }
    }
}

