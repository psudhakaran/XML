---
title: XML
key: xml
---

## Language-Specific Properties

Discover and update the XML-specific [properties](/analysis/analysis-parameters/) in: <!-- sonarcloud -->Project <!-- /sonarcloud -->**[Administration > General Settings > XML](/#sonarqube-admin#/admin/settings?category=xml)**

<!-- sonarqube -->
## Related Pages
* [Adding Coding Rules](/extend/adding-coding-rules/)
<!-- /sonarqube -->
