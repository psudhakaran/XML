package org.sonar.plugins.xml.checks;

import org.junit.jupiter.api.Test;
import org.sonarsource.analyzer.commons.xml.checks.SonarXmlCheck;
import org.sonarsource.analyzer.commons.xml.checks.SonarXmlCheckVerifier;

class EmptyDescriptionCheckTest {

	  private static final SonarXmlCheck CHECK = new EmptyDescriptionCheck();

	  @Test
	  void test() {
		  SonarXmlCheckVerifier.verifyIssues("EmptyDescriptionCheck.xml", CHECK);

	   
	  }
	}



